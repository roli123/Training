package com.bank.services;

import java.sql.SQLException;

import com.bank.beans.BankBean;
import com.bank.dao.BankDAO;
import com.bank.exception.AccountNotCreatedException;

import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.ZeroBalanceException;

public class BankService implements BankServiceI
{
	int balance;
	BankDAO bankDAO =  new BankDAO();
	BankBean bankBean = new BankBean();
	
	public boolean createAccount(String name, String phoneNo,String password, long accountNo,  int balance) throws AccountNotCreatedException, ClassNotFoundException, SQLException
	{
		BankBean bankBean = new BankBean();
	    bankBean.setName(name);
	    bankBean.setPhoneNo(phoneNo);
	    bankBean.setPassword(password);
	    bankBean.setAccountNo(accountNo);
	    bankBean.setBalance(balance);
	    
	    boolean result = bankDAO.createAccount(bankBean);
	    return result;
      
     }
	public int showBalance(long accountNo) throws ZeroBalanceException, ClassNotFoundException, SQLException
	{
		  balance = bankDAO.showBalance(accountNo);
		 return balance;
	}
	public int depositAmount(long accountNo,int deposit) throws ClassNotFoundException, SQLException, ZeroBalanceException
	{
		int balance1 = showBalance(accountNo)+deposit;
		 balance = bankDAO.depositAmount(accountNo, balance1);
		return balance;
	}
	public int withdrawAmount(long accountNo , int withdraw) throws InsufficientBalanceException, ClassNotFoundException, SQLException, ZeroBalanceException
	{
		int balance1 = showBalance(accountNo)-withdraw;
		balance =bankDAO.withdrawAmount(accountNo, balance1);
		return balance;
	}
	public boolean fundTransfer(long accountNo, long accno , int amount) throws ClassNotFoundException, SQLException, ZeroBalanceException
	{
		int balance1 = showBalance(accountNo);
		if(balance1>amount)
		{
			boolean transfer = bankDAO.fundTransfer(accountNo,accno,amount);
			return transfer;
		}
		return false;
		
	}
	public boolean validateAccount(long accountNo, String password) throws ClassNotFoundException, SQLException
	{
		boolean b = bankDAO.validateAccount(accountNo,password);
		return b;
	}
	public int nameValidate(String name)
	{
		if(name.matches("[A-Z][a-zA-Z]*"))
			return 1;
		else
			return 0;
	}
	public int mobNoValidate(String phoneNo)
	{
		//String mob = Long.toString(phoneNo);
	if(phoneNo.matches("[a-z]*"))
		return 0;
	else
		if(phoneNo.matches("[6-9][0-9]{9}"))
				return 1;
		else
			return 0;
	}
	public int passwordValidate(String password) 
	{
		if(password.length()>3)
			return 1;
		else
			return 0;
	}
	public int checkBalance(int balance) {
		if(balance>=1000)
		return 1;
		else 
			return 0;
	}
	public String getTransaction(long accountNo) throws AccountNotCreatedException, SQLException {
		String st=bankDAO.getTransaction(accountNo);
		if(st!=null) {
			return st;
		}else {
			throw new AccountNotCreatedException();
		}
		               
	}
	
	
	
}