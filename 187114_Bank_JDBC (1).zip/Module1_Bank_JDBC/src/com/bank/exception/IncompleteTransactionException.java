
package com.bank.exception;

public class IncompleteTransactionException extends Exception{
       public String toString()
       {
    	   return "transaction failed";
       }
}
