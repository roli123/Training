package com.bank.exception;

public class AccountNotCreatedException extends Exception {
   public String toString()
   {
	   return "Problem in account Sorry for inconvenience , try later";
   }
}
