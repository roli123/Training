package com.bank.exception;

public class InsufficientBalanceException extends Exception{
	
	public String toString()
	{
		return "Insufficient balance\n";
	}
}
